$(document).ready(function(){
    $('.section-tree_right-box').click(function(){
        $('.section-tree_right-box').not(this).find('p').slideUp(300);
        $(this).find('p').slideToggle(300);
});
    Swal.fire({
        title: "welcome",
        text: "You clicked the button!",
        icon: "success"
      });
});