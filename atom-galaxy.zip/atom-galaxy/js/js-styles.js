/*---------------------------------------------------Swiper-------------------------------------------------------------------*/
const swiperTravel = new Swiper('.travel_swiper', {
  loop: true,
  spaceBetween: '32',
  grabCursor: true,
  slidesPerView: 'auto',
  centeredSlides: 'auto',
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  },
  breakpoints:{
    600:{
      slidesPerView: 2,
    },
    900:{
      slidesPerView: 3,
    },
  }
});
/*---------------------------------------------------Swiper-------------------------------------------------------------------*/
const div = document.querySelectorAll('div[id]');


const scrollActive = () =>{
  const scrollDown = window.scrollY;

  div.forEach(current =>{
    const divHeight = current.offsetHeight ,
          divTop = current.offsetTop - 58 ,
          divId = current.getAttribute('id') ,
          divClass = document.querySelector('.nav_menu a[href*="' + divId + '"]');
    if(divClass){
      if(scrollDown > divTop && scrollDown <= divTop + divHeight){
        divClass.classList.add('active-link');
      }else{
        divClass.classList.remove('active-link');
      }
    }
  });
};
window.addEventListener('scroll',scrollActive);



